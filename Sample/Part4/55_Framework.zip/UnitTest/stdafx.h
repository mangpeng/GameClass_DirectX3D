#pragma once

#include "Framework.h"
#pragma comment(lib, "Framework.lib")