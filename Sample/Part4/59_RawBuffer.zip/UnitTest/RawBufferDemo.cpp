#include "stdafx.h"
#include "RawBufferDemo.h"

void RawBufferDemo::Initialize()
{
	
}

void RawBufferDemo::Update()
{
	
}

void RawBufferDemo::Render()
{
	
}