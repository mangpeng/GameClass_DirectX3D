#include "Framework.h"
#include "Collider.h"

Collider::Collider(Transform * transform, Transform * init)
	: transform(transform), init(init)
{
	lines[0] = Vector3(-0.5f, -0.5f, -0.5f); //Min
	lines[1] = Vector3(-0.5f, +0.5f, -0.5f);
	lines[2] = Vector3(+0.5f, -0.5f, -0.5f);
	lines[3] = Vector3(+0.5f, +0.5f, -0.5f);
	lines[4] = Vector3(-0.5f, -0.5f, +0.5f);
	lines[5] = Vector3(-0.5f, +0.5f, +0.5f);
	lines[6] = Vector3(+0.5f, -0.5f, +0.5f);
	lines[7] = Vector3(+0.5f, +0.5f, +0.5f); //Max
}

Collider::~Collider()
{

}

void Collider::Update()
{
	
}

void Collider::Render(Color color)
{
	Transform temp;
	temp.World(transform->World());

	if (init != NULL)
		temp.World(init->World() * transform->World());

	Matrix world = temp.World();


	Vector3 dest[8];
	for (UINT i = 0; i < 8; i++)
		D3DXVec3TransformCoord(&dest[i], &lines[i], &world);

	//Front
	DebugLine::Get()->RenderLine(dest[0], dest[1], color);
	DebugLine::Get()->RenderLine(dest[1], dest[3], color);
	DebugLine::Get()->RenderLine(dest[3], dest[2], color);
	DebugLine::Get()->RenderLine(dest[2], dest[0], color);

	//Backward
	DebugLine::Get()->RenderLine(dest[4], dest[5], color);
	DebugLine::Get()->RenderLine(dest[5], dest[7], color);
	DebugLine::Get()->RenderLine(dest[7], dest[6], color);
	DebugLine::Get()->RenderLine(dest[6], dest[4], color);

	//Side
	DebugLine::Get()->RenderLine(dest[0], dest[4], color);
	DebugLine::Get()->RenderLine(dest[1], dest[5], color);
	DebugLine::Get()->RenderLine(dest[2], dest[6], color);
	DebugLine::Get()->RenderLine(dest[3], dest[7], color);
}

bool Collider::Intersection(Ray & ray, float * outDistance)
{
	*outDistance = 0.0f;

	Vector3 dest[8];

	Transform temp;
	temp.World(transform->World());

	if (init != NULL)
		temp.World(init->World() * transform->World());

	Matrix world = temp.World();

	Vector3 minPosition, maxPosition;
	D3DXVec3TransformCoord(&minPosition, &lines[0], &world);
	D3DXVec3TransformCoord(&maxPosition, &lines[7], &world);

	if (fabsf(ray.Direction.x) == 0.0f) ray.Direction.x = 1e-6f;
	if (fabsf(ray.Direction.y) == 0.0f) ray.Direction.y = 1e-6f;
	if (fabsf(ray.Direction.z) == 0.0f) ray.Direction.z = 1e-6f;


	float minValue = 0.0f, maxValue = FLT_MAX;

	//Check X
	if (fabsf(ray.Direction.x) >= 1e-6f)
	{
		float value = 1.0f / ray.Direction.x;
		float minX = (minPosition.x - ray.Position.x) * value;
		float maxX = (maxPosition.x - ray.Position.x) * value;

		if (minX > maxX)
		{
			float temp = minX;
			minX = maxX;
			maxX = temp;
		}

		minValue = max(minX, minValue);
		maxValue = min(maxX, maxValue);

		if (minValue > maxValue)
			return false;
	}
	else if (ray.Position.x < minPosition.x || ray.Position.x > maxPosition.x)
		return false;

	//Check Y
	if (fabsf(ray.Direction.y) >= 1e-6f)
	{
		float value = 1.0f / ray.Direction.y;
		float minY = (minPosition.y - ray.Position.y) * value;
		float maxY = (maxPosition.y - ray.Position.y) * value;

		if (minY > maxY)
		{
			float temp = minY;
			minY = maxY;
			maxY = temp;
		}

		minValue = max(minY, minValue);
		maxValue = min(maxY, maxValue);

		if (minValue > maxValue)
			return false;
	}
	else if (ray.Position.y < minPosition.y || ray.Position.y > maxPosition.y)
		return false;


	//Check Z
	if (fabsf(ray.Direction.z) >= 1e-6f)
	{
		float value = 1.0f / ray.Direction.z;
		float minZ = (minPosition.z - ray.Position.z) * value;
		float maxZ = (maxPosition.z - ray.Position.z) * value;

		if (minZ > maxZ)
		{
			float temp = minZ;
			minZ = maxZ;
			maxZ = temp;
		}

		minValue = max(minZ, minValue);
		maxValue = min(maxZ, maxValue);

		if (minValue > maxValue)
			return false;
	}
	else if (ray.Position.z < minPosition.z || ray.Position.z > maxPosition.z)
		return false;

	*outDistance = minValue;
	return true;
}
