#pragma once

#include "Framework.h"
#pragma comment(lib, "Framework.lib")

#include "Assimp/Importer.hpp"
#include "Assimp/scene.h"
#include "Assimp/postprocess.h"
#pragma comment(lib, "Assimp/assimp-vc140-mt.lib")