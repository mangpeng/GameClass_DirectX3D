#pragma once

class Model
{
public:
	typedef VertexTextureNormalTangentBlend ModelVertex;
};